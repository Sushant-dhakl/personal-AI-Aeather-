# ◈ AETHER — Personal AI Mentor

A dark-mode personal AI web app with memory, goal tracking, and daily check-ins.

---

## Folder Structure

```
aether/
├── index.html     ← The entire UI (chat + sidebar)
├── style.css      ← All styling (dark mode, layout, animations)
├── script.js      ← Frontend logic (chat, goals, memory)
├── server.js      ← Node.js backend (routes API calls to OpenAI/Gemini)
├── package.json   ← Node dependencies
└── README.md      ← This file
```

---

## Step-by-Step Setup

### 1. Install Node.js
Download from https://nodejs.org — get the LTS version (18+).
Check it works: `node --version`

### 2. Get your project files
Put all files in a folder called `aether/`.

### 3. Install dependencies
```bash
cd aether
npm install
```
This installs Express (the only dependency).

### 4. Get an API Key

**Option A — OpenAI (recommended for beginners)**
1. Go to https://platform.openai.com/api-keys
2. Create a new secret key
3. Copy it (starts with `sk-...`)

**Option B — Google Gemini (free tier available)**
1. Go to https://aistudio.google.com/app/apikey
2. Create an API key
3. Copy it

### 5. Set your API key

**Easiest way** — paste directly in server.js:
```js
const OPENAI_API_KEY = 'sk-your-actual-key-here';
```

**Better way** — use environment variables (key never touches your code):
```bash
# Mac/Linux:
export OPENAI_API_KEY=sk-your-key-here

# Windows (Command Prompt):
set OPENAI_API_KEY=sk-your-key-here

# Windows (PowerShell):
$env:OPENAI_API_KEY="sk-your-key-here"
```

### 6. Choose your AI provider
In `server.js`, change this line if using Gemini:
```js
const AI_PROVIDER = 'gemini';   // or 'openai'
```

### 7. Run the app
```bash
npm start
```

Open your browser: **http://localhost:3000**

---

## How to Use

| Feature | How |
|---------|-----|
| **Chat** | Type in the box, press Enter |
| **Add a goal** | Click `+` in the goals panel |
| **Mark goal done** | Click the checkbox next to a goal |
| **Daily check-in** | Click "Start Today's Check-In" |
| **Clear chat** | Click "Clear" in the top bar |
| **Reset memory** | Click `↺` in the Memory panel |

---

## Memory — What Aether Remembers

Aether auto-detects facts from your messages:
- "my name is Sushant" → stores your name
- "I am 22 years old" → stores your age
- "I live in Kathmandu" → stores your location
- "I wake up at 6am" → stores your wake time

Memory is stored locally in your browser (localStorage) — it never leaves your machine.

---

## Suggested Improvements (Next Steps)

1. **Persistent backend storage** — swap localStorage for SQLite or MongoDB
2. **Streak tracking calendar** — visual heatmap of goal completions
3. **Multiple users** — add a simple login system
4. **Voice input** — use Web Speech API for voice messages
5. **Notifications** — browser notifications for check-in reminders
6. **Export data** — download your goals + memory as JSON

---

## Troubleshooting

| Problem | Fix |
|---------|-----|
| `Cannot find module 'express'` | Run `npm install` |
| `401 Unauthorized` | Check your API key is correct |
| `429 Too Many Requests` | You've hit rate limits — wait a minute |
| Port already in use | Change PORT in server.js to 3001 |
| White screen | Open browser console (F12) and check for errors |
