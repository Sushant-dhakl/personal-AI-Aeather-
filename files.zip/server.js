/* =====================================================
   AETHER — server.js
   Node.js + Express backend
   Handles AI API calls (supports OpenAI & Gemini)
   ===================================================== */

const express = require('express');
const path    = require('path');

const app  = express();
const PORT = process.env.PORT || 3000;

// ── Middleware ────────────────────────────────────────
app.use(express.json());
// Serve all files in the current folder as static files
// (index.html, style.css, script.js)
app.use(express.static(path.join(__dirname)));

// ── Configuration ─────────────────────────────────────
// CHOOSE your AI provider: 'openai' or 'gemini'
const AI_PROVIDER = process.env.AI_PROVIDER || 'openai';

// Set your API key here OR use environment variables (recommended)
// To set via terminal:
//   Mac/Linux:  export OPENAI_API_KEY=sk-...
//   Windows:    set OPENAI_API_KEY=sk-...
const OPENAI_API_KEY = process.env.OPENAI_API_KEY || 'YOUR_OPENAI_KEY_HERE';
const GEMINI_API_KEY = process.env.GEMINI_API_KEY || 'YOUR_GEMINI_KEY_HERE';

// ── Chat Endpoint ─────────────────────────────────────
// Frontend calls POST /api/chat with { messages, system }
app.post('/api/chat', async (req, res) => {
  const { messages, system } = req.body;

  if (!messages || !Array.isArray(messages)) {
    return res.status(400).json({ error: 'Invalid request: messages array required' });
  }

  try {
    let reply;

    if (AI_PROVIDER === 'openai') {
      reply = await callOpenAI(messages, system);
    } else if (AI_PROVIDER === 'gemini') {
      reply = await callGemini(messages, system);
    } else {
      return res.status(400).json({ error: `Unknown AI_PROVIDER: ${AI_PROVIDER}` });
    }

    res.json({ reply });

  } catch (err) {
    console.error('AI API Error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// ── OpenAI Integration ────────────────────────────────
async function callOpenAI(messages, systemPrompt) {
  const response = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${OPENAI_API_KEY}`,
    },
    body: JSON.stringify({
      model: 'gpt-4o-mini',     // Cheap + fast. Change to 'gpt-4o' for smarter answers
      max_tokens: 300,           // Keep responses short
      temperature: 0.85,         // A bit of personality
      messages: [
        { role: 'system', content: systemPrompt },
        ...messages,             // Full conversation history
      ],
    }),
  });

  if (!response.ok) {
    const err = await response.json();
    throw new Error(err.error?.message || 'OpenAI API error');
  }

  const data = await response.json();
  return data.choices[0].message.content;
}

// ── Gemini Integration ────────────────────────────────
async function callGemini(messages, systemPrompt) {
  // Gemini uses a different message format than OpenAI
  // We convert our messages to Gemini's "contents" format
  const contents = messages.map(m => ({
    role: m.role === 'assistant' ? 'model' : 'user',
    parts: [{ text: m.content }],
  }));

  const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${GEMINI_API_KEY}`;

  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      system_instruction: { parts: [{ text: systemPrompt }] },
      contents,
      generationConfig: {
        maxOutputTokens: 300,
        temperature: 0.85,
      },
    }),
  });

  if (!response.ok) {
    const err = await response.json();
    throw new Error(err.error?.message || 'Gemini API error');
  }

  const data = await response.json();
  return data.candidates[0].content.parts[0].text;
}

// ── Start Server ──────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\n  ◈ AETHER is running`);
  console.log(`  → Open http://localhost:${PORT} in your browser\n`);
  console.log(`  Provider: ${AI_PROVIDER.toUpperCase()}`);
  if (AI_PROVIDER === 'openai' && OPENAI_API_KEY === 'YOUR_OPENAI_KEY_HERE') {
    console.warn(`  ⚠️  No OpenAI key set! Add it to server.js or run: export OPENAI_API_KEY=sk-...`);
  }
  if (AI_PROVIDER === 'gemini' && GEMINI_API_KEY === 'YOUR_GEMINI_KEY_HERE') {
    console.warn(`  ⚠️  No Gemini key set! Add it to server.js or run: export GEMINI_API_KEY=...`);
  }
});
